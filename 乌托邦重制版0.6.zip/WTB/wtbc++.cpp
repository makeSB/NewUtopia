#include<iostream>
#include<easyx.h>
using namespace std;
//0�� 1½ 

const int w=26;
const int h=20;
const int size=20;
const int size_tp=30;
int p1_jb=0;//Ǯ 
int p2_jb=0;
int jz_jb[10];//��������Ǯ 
ExMessage msg;
IMAGE tup_bg[2];//����ͼ�� 
IMAGE tup_jz[10];//����ͼ�� 
IMAGE s_or_f[3];//�Ƿ��ʺϽ����ͼ�� 
IMAGE tup_tp[10];//�Ƿ��ʺϽ����ͼ�� 
IMAGE Ui;
int key=0;
int jz_map[h][w];
int p1_r;//ס�� 
int p2_r;
int p1_s;//ʳ�� 
int p2_s;
int p1_w;//��Ⱦ 
int p2_w;
int p1_kr;//�����˿� 
int p2_kr; 
int map[h][w]= {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};
void main_game(int side){
	for(int i=3;i>=0;){
			if(peekmessage(&msg, EX_MOUSE)){
			switch(msg.message){//ѡ��--����Ƿ��� 
				case WM_LBUTTONUP:	//ѡ��--����Ƿ��� --�������� 
					int sz=0;//ѡ���Ƿ� 
					int xk_jz=0;//�������� 
					int qk_x=msg.x/size;
					int qk_y=msg.y/size;
					if(qk_x<=w-1&&qk_y<=h-1) sz=1;//ѡ���Ƿ� ��ͼ�� 
					if(side==0&&(qk_x<w/2&&(map[qk_y][qk_x]==1))){//�Ƿ��ʺϽ��� 
						setlinecolor(GREEN);//��Ϊ��ɫ 
						putimage(w*size+size,0,&s_or_f[1]);
						xk_jz=1;
						
					}
					else if(side==1&&(qk_x>=w/2&&(map[qk_y][qk_x]==1))){//�Ƿ��ʺϽ��� 
						setlinecolor(RED);//��Ϊ��ɫ 
						putimage(w*size+size,0,&s_or_f[1]);
						xk_jz=1;
						
					}
					if(sz)
						rectangle(qk_x*size,qk_y*size,(qk_x+1)*size,(qk_y+1)*size);
					while(sz){
						peekmessage(&msg, EX_MOUSE);
						switch(msg.message){
							case WM_RBUTTONUP:
								sz=0;
							case  WM_LBUTTONUP://������� 
								if((msg.x>=(w-1)*size)&&(msg.y<=300)&&(jz_map[qk_y][qk_x]==0)){
									key=msg.y/size_tp+1;//��ť 
									if(xk_jz==1){//�ж��Ƿ��ܽ��죨xk_jx���ж� �㷨�ɼ�ǰ�� 
										if(side==0){
											if(p1_jb>=jz_jb[key]){
												p1_jb-=jz_jb[key];
												jz_map[qk_y][qk_x]=key;
												sz=0;
												i--;
											}
										}
										if(side==1){
											if(p2_jb>=jz_jb[key]){
												p2_jb-=jz_jb[key];
												jz_map[qk_y][qk_x]=key;
												sz=0;
												i--;
											}
										}
									}
								}
						}
					}
					for(int i=0;i<h;i++) {
	 					for(int j=0;j<w;j++)
	 						putimage(j*size,i*size,&tup_bg[map[i][j]]);
	 				}//��ͼ��� 
	 				for(int i=0;i<h;i++) {
						for(int j=0;j<w;j++)
	 						putimage(j*size,i*size,&tup_jz[jz_map[i][j]]);
	 				}//������� 
	 				
	 				putimage(w*size+size,0,&s_or_f[0]);
	 				sz=0;
	 				xk_jz=0;
	 				cout<<p2_jb<<endl;
	 				break;
	 				
			}
		}
	}
}
void jesuan(bool funk_player){
	int rooms=0;
	int xiaolv=1;
	int pollution=0;
	int money=0; 
	int food=0; 
	int i;
	int number_gc=0;
	int finish_x;
	int can_use_prople=0; 
	if(funk_player==true){//�ж���P2  �ӵ�ͼһ�뿪ʼ 
		i=w/2; 
		finish_x=w;
	}
	else{
		i=0;
		finish_x=w/2;//�ж���P1  ��ͷ��ʼ �� ��ͼһ��
	}
	for(;i<finish_x;i++){
 		for(int j=0;j<20;j++){
 			if(jz_map[j][i]==4){//ѧУ 
 				xiaolv+=0.5;// ��Ч�� 
			}
			else if(jz_map[j][i]==2){//���� 
 				number_gc+=1;//�������� 
			}
			else if(jz_map[j][i]==6)//ס�� 
 			{
 				rooms+=500;//ס��+500 
			}
			else if	(jz_map[j][i]==3){//�� 
 				food+=500;//ʳ��+500 
			}
		}		
 	}
 	i=0;//���� 
 	can_use_prople=min(food,rooms); 
 	for(;i<finish_x;i++){
 		for(int j=0;j<h;j++){
 			if(jz_map[j][i]==2){//���� 
 				money+=((4*xiaolv)*(can_use_prople/(number_gc*200)));//�������˿�/��Ҫ�˿ڣ�*����Ǯ 4* Ч�� �� 
 				pollution+=5;//��Ⱦ	
			}
 			else if(jz_map[j][i]==5){//ҽԺ 
 				rooms+=200;//ס��+200 
 				pollution-=5;//��Ⱦ-5 
 				if(pollution<0){
 					pollution=0;
				}
			}
 			
		}
	}
	cout<<money<<endl;
	if(funk_player==true){
		p2_r=rooms;
		p2_jb+=money;
		p2_s=food;
		p2_w=pollution;
		p2_kr=can_use_prople;
	}
	else{
		p1_r=rooms;
		p1_jb+=money;
		p1_s=food;
		p1_w=pollution;
		p1_kr=can_use_prople;
	}
}
int main(){
	jz_jb[1]=50;
	jz_jb[2]=40;
	jz_jb[3]=0;
	jz_jb[4]=35;
	jz_jb[5]=75;
	jz_jb[6]=60;
	p1_jb=10000;
	p2_jb=100000;
	releasecapture();
	ExMessage msg;
	initgraph(w*size+220,h*size, EX_SHOWCONSOLE);
	loadimage(&tup_bg[0], _T("picture\\dx\\hai.png"));
	loadimage(&tup_bg[1], _T("picture\\dx\\lu.png"));
	loadimage(&tup_jz[1], _T("picture\\db\\bl.png"));
	loadimage(&tup_jz[2], _T("picture\\db\\gc.png"));
	loadimage(&tup_jz[3], _T("picture\\db\\ta.png"));
	loadimage(&tup_jz[4], _T("picture\\db\\xx.png"));
	loadimage(&tup_jz[5], _T("picture\\db\\yy.png"));
	loadimage(&tup_jz[6], _T("picture\\db\\zf.png"));
	loadimage(&tup_tp[1], _T("picture\\bq\\blp.png"));
	loadimage(&tup_tp[2], _T("picture\\bq\\gcp.png"));
	loadimage(&tup_tp[3], _T("picture\\bq\\tap.png"));
	loadimage(&tup_tp[4], _T("picture\\bq\\xxp.png"));
	loadimage(&tup_tp[5], _T("picture\\bq\\yyp.png"));
	loadimage(&tup_tp[6], _T("picture\\bq\\zfp.png"));
	setlinecolor(GREEN);//��Ϊ��ɫ 
	setlinestyle(PS_SOLID | PS_ENDCAP_SQUARE, 3);
	for(int i=0;i<h;i++) {
		for(int j=0;j<w;j++)
	 		putimage(j*size,i*size,&tup_bg[map[i][j]]);
	 		
	}
	for(int i=0;i<6;i++){
		putimage(w*size,i*size_tp,&tup_tp[i+1]);
	}
		 
	
	while(1){
		//ѡ�� 
 		main_game(1);
		jesuan(true);
		cout<<"����"<<p2_r<<endl;
 		cout<<"Ǯ"<<p2_jb<<endl;
 		cout<<"ʳ��"<<p2_s<<endl;
 		cout<<"��Ⱦ"<<p2_w<<endl;
 		cout<<endl;
 		main_game(0);
 		jesuan(false);
 		cout<<"����"<<p1_r<<endl;
 		cout<<"Ǯ"<<p1_jb<<endl;
 		cout<<"ʳ��"<<p1_s<<endl;
 		cout<<"��Ⱦ"<<p1_w<<endl;
 		cout<<endl;
		
	}
	return 0;
}





