#include<stdio.h>
#include<conio.h>
#include<bits/stdc++.h>
#include<easyx.h>
using namespace std;
//0�� 1½ 
const int w=26;
const int h=20;
const int size=20;
const int zhen=6000;
const int size_tp=30;
int p1_jb=0;//Ǯ 
int p2_jb=0;
int jz_jb[10];//��������Ǯ 
int dw_jb[10];//������λǮ 
char yd;
int witch_dw;
ExMessage msg;
IMAGE tup_bg[2];//����ͼ�� 
IMAGE tup_jz[10];//����ͼ�� 
IMAGE tup_dw[10];//��λͼ�� 
IMAGE tup_dw_tp[10];//��λͼ�� 
IMAGE s_or_f[3];//�Ƿ��ʺϽ����ͼ�� 
IMAGE tup_tp[20];//�Ƿ��ʺϽ����ͼ�� 
IMAGE Ui;
int key=0;
int jz_map[h][w];
int p1_r;//ס�� 
int p2_r;
int p1_s;//ʳ�� 
int p2_s;
int p1_w;//��Ⱦ 
int p2_w;
int p1_kr;//�����˿� 
int p2_kr; 
double xl=0;
int fps=0;
int map_dw[h][w]; 
int map_dx[h][w]= {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};
void funk_windows(){
	BeginBatchDraw();
	for(int i=0;i<h;i++) {
		for(int j=0;j<w;j++){
			putimage(j*size,i*size,&tup_bg[map_dx[i][j]]);
			putimage(j*size,i*size,&tup_jz[jz_map[i][j]]);
			putimage(j*size,i*size,&tup_dw[map_dw[i][j]]);
			if(map_dw[i][j]==1){
				putimage(j*size,i*size,&tup_dw[1]);
			}
		}		
	}//��ͼ��� 
	EndBatchDraw();
} 
void jesuan(bool funk_player){
	int rooms=0;
	int xiaolv=1;
	int pollution=0;
	int money=0; 
	int food=0; 
	int i;
	int number_gc=0;
	int finish_x;
	int can_use_prople=0; 
	if(funk_player==true){//�ж���P2  �ӵ�ͼһ�뿪ʼ 
		i=w/2; 
		finish_x=w;
	}
	else{
		i=0;
		finish_x=w/2;//�ж���P1  ��ͷ��ʼ �� ��ͼһ��
	}
	for(;i<finish_x;i++){
 		for(int j=0;j<20;j++){
 			if(jz_map[j][i]==4){//ѧУ 
 				xiaolv+=0.5;// ��Ч�� 
			}
			else if(jz_map[j][i]==2){//���� 
 				number_gc+=1;//�������� 
			}
			else if(jz_map[j][i]==6)//ס�� 
 			{
 				rooms+=500;//ס��+500 
			}
			else if	(jz_map[j][i]==3){//�� 
 				food+=500;//ʳ��+500 
			}
		}		
 	}
 	i=0;//���� 
 	can_use_prople=min(food,rooms); 
 	for(;i<finish_x;i++){
 		for(int j=0;j<h;j++){
 			if(jz_map[j][i]==2){//���� 
 				money+=((10*xiaolv)*(can_use_prople/(number_gc*200)));//�������˿�/��Ҫ�˿ڣ�*����Ǯ 4* Ч�� �� 
 				pollution+=5;//��Ⱦ	
			}
 			else if(jz_map[j][i]==5){//ҽԺ 
 				rooms+=200;//ס��+200 
 				pollution-=5;//��Ⱦ-5 
 				if(pollution<0){
 					pollution=0;
				}
			}
 			
		}
	}
	if(funk_player==true){//���ݶһ� 
		p2_r=rooms;
		p2_jb+=money;
		p2_s=food;
		p2_w=pollution;
		p2_kr=can_use_prople;
		int nember_gc_p=number_gc*200;
		xl=1.0*can_use_prople/nember_gc_p;
		if(xl>1){
			xl=1;
		}
	}
	else{
		p1_r=rooms;
		p1_jb+=money;
		p1_s=food;
		p1_w=pollution;
		p1_kr=can_use_prople;
	}
}
void fuck_windows_sz(){//״̬��ʾ 
	BeginBatchDraw();
	for(int i=0;i<7;i++){
		putimage(w*size,i*size_tp,&tup_tp[i+1]);
		putimage(w*size+32+size_tp,i*size_tp,&tup_dw_tp[i+1]);
	}
	putimage(w*size+30,0,&tup_tp[11]);//���� 
	line(w*size+45,220,w*size+45,(220-220*xl));
	EndBatchDraw();
}
void main_game(int side){
	for(int i=3;i>=0;){//�Ҳ�������3��ʲô�õ�����Ҫ�� 
		int sz=0;//ѡ���Ƿ� 
		int xk_jz=0;//�������� 
		int qk_x=msg.x/size;
		int qk_y=msg.y/size;
		if(qk_x<w) {//�ڵ�ͼ�ڻ� 
			BeginBatchDraw();
			rectangle(qk_x*size,qk_y*size,(qk_x+1)*size,(qk_y+1)*size);
			EndBatchDraw();
		}
		
		if(peekmessage(&msg, EX_MOUSE)){
			funk_windows();//ˢ�� 
			switch(msg.message){//ѡ��--����Ƿ��� 
				case WM_LBUTTONUP:	//ѡ��--����Ƿ��� --�������� 
					if(qk_x<=w-1&&qk_y<=h-1) sz=1;//ѡ���Ƿ� ��ͼ�� 
					if(side==0&&(qk_x<w/2&&(map_dx[qk_y][qk_x]==1))){//�Ƿ��ʺϽ��� 
						setlinecolor(GREEN);//��Ϊ��ɫ 
						putimage(w*size+size,0,&s_or_f[1]);
						xk_jz=1;
	
					}
					else if(side==1&&(qk_x>=w/2&&(map_dx[qk_y][qk_x]==1))){//�Ƿ��ʺϽ��� 
						setlinecolor(RED);//��Ϊ��ɫ 
						putimage(w*size+size,0,&s_or_f[1]);
						xk_jz=1;
						
					}
					if(sz)
						rectangle(qk_x*size,qk_y*size,(qk_x+1)*size,(qk_y+1)*size);
					if(jz_map[qk_y][qk_x]==7){//���˴��� 
						xk_jz=0;
						bool jz_xz=true;//����ѡ����ģʽ��־ 
						while(jz_xz){
							peekmessage(&msg, EX_MOUSE);
							switch(msg.message){					
								case WM_RBUTTONUP:
									jz_xz=0;
								case  WM_LBUTTONUP://������� 
									if(msg.x>=((w-1)*size+size_tp+32)){
										int key=msg.y/size_tp+1;
										if(side==1){
											p2_jb>=dw_jb[key];
											p2_jb-=dw_jb[key];
											if(map_dx[qk_y][qk_x-1]==0){
												map_dw[qk_y][qk_x-1]=1;
											}	
											else if(map_dx[qk_y][qk_x+1]==0){
												map_dw[qk_y][qk_x+1]=1;
											}	
											else if(map_dx[qk_y-1][qk_x]==0){
												map_dw[qk_y-1][qk_x]=1;
											}	
											else if(map_dx[qk_y+1][qk_x]==0){
												map_dw[qk_y+1][qk_x]=1;
											}	
											jz_xz=0;
											sz=0;
										}
									}
								
							}
						}
					}
					if(map_dw[qk_y][qk_x]==1){//���˴� 
						int dw_xk=0;
						bool dw_xz=true;//����ѡ���ƶ� 
						sz=0;
						witch_dw=map_dw[qk_y][qk_x];
						while(dw_xz){
							peekmessage(&msg, EX_MOUSE);
							int Qk_X=msg.x/size;
							int Qk_Y=msg.y/size;
							if(msg.message==WM_RBUTTONUP){
								if(Qk_X<w&&(max(qk_x,Qk_X)-min(qk_x,Qk_X)+max(qk_y,Qk_Y)-min(qk_y,Qk_Y))<10&&(map_dx[Qk_Y][Qk_X]==0)){
									map_dw[qk_y][qk_x]=0;
									map_dw[Qk_Y][Qk_X]=witch_dw;
									dw_xz=0;
								}
							}	
						}
					}
					while(sz){
						peekmessage(&msg, EX_MOUSE);
						switch(msg.message){
							case WM_RBUTTONUP:
								sz=0;
							case  WM_LBUTTONUP://������� 
								if((msg.x>=(w-1)*size)&&(msg.y<=300)&&(jz_map[qk_y][qk_x]==0)){
									key=msg.y/size_tp+1;//��ť 
									if(xk_jz==1){//�ж��Ƿ��ܽ��죨xk_jx���ж� �㷨�ɼ�ǰ�� 
										if(side==0){
											if(p1_jb>=jz_jb[key]){// ��Ǯ 
												p1_jb-=jz_jb[key];//��Ǯ 
												jz_map[qk_y][qk_x]=key;;//���� 
												sz=0;
												i--;
											}
										}
										if(side==1){
											if(p2_jb>=jz_jb[key]){// ��Ǯ 
												if(key==7){//���� 
													if(map_dx[qk_y][qk_x+1]==0||map_dx[qk_y][qk_x-1]==0||map_dx[qk_y-1][qk_x]==0||map_dx[qk_y+1][qk_x]==0){
														p2_jb-=jz_jb[key];//��Ǯ 
														jz_map[qk_y][qk_x]=key;//���� 
														sz=0;
														i--;
													}
												}
												else{
													p2_jb-=jz_jb[key];//��Ǯ 
													jz_map[qk_y][qk_x]=key;//���� 
													sz=0;
													i--;
												}
												
											}
										}
										
									}
								}
						}
					}
					
	 				funk_windows();
	 				sz=0;
	 				xk_jz=0;
	 				jesuan(true);
	 				fuck_windows_sz();
	 				break;
	 				
	 				
			}
		}
	}
}


int main(){
	//��������Ǯ 
	jz_jb[1]=50;
	jz_jb[2]=40;
	jz_jb[3]=0;
	jz_jb[4]=35;
	jz_jb[5]=75;
	jz_jb[6]=60;
	jz_jb[7]=80;
	dw_jb[1]=30;
	//��ʼ��Ǯ 
	p1_jb=10000;
	p2_jb=100000;
	releasecapture();
	//��ͼ
	for(int i=0;i<h;i++)
		for(int j=0;j<w;j++)
			map_dw[i][j]=0;
	ExMessage msg;
	initgraph(w*size+220,h*size, EX_SHOWCONSOLE);
	loadimage(&tup_bg[0], _T("picture\\dx\\hai.png"));
	loadimage(&tup_bg[1], _T("picture\\dx\\lu.png"));
	loadimage(&tup_jz[1], _T("picture\\db\\bl.png"));
	loadimage(&tup_jz[2], _T("picture\\db\\gc.png"));
	loadimage(&tup_jz[3], _T("picture\\db\\ta.png"));
	loadimage(&tup_jz[4], _T("picture\\db\\xx.png"));
	loadimage(&tup_jz[5], _T("picture\\db\\yy.png"));
	loadimage(&tup_jz[6], _T("picture\\db\\zf.png"));
	loadimage(&tup_jz[7], _T("picture\\db\\cw.png"));
	loadimage(&tup_tp[1], _T("picture\\bq\\blp.png"));
	loadimage(&tup_tp[2], _T("picture\\bq\\gcp.png"));
	loadimage(&tup_tp[3], _T("picture\\bq\\tap.png"));
	loadimage(&tup_tp[4], _T("picture\\bq\\xxp.png"));
	loadimage(&tup_tp[5], _T("picture\\bq\\yyp.png"));
	loadimage(&tup_tp[6], _T("picture\\bq\\zfp.png"));
	loadimage(&tup_tp[7], _T("picture\\bq\\cw.png"));
	loadimage(&tup_tp[11], _T("picture\\bq\\zh.png"));
	loadimage(&tup_dw[1], _T("picture\\rw\\zj.png"));
	loadimage(&tup_dw_tp[1], _T("picture\\bq\\zj.png"));
	setlinecolor(RED);//��Ϊ��ɫ 
	setlinestyle(PS_SOLID | PS_ENDCAP_SQUARE, 3);
	funk_windows();
	fuck_windows_sz();
	while(1){
		fps++;
		fps=fps%(zhen+1);
		//ѡ��
		if(fps==zhen){
			fuck_windows_sz();
			main_game(1);
			jesuan(true);
			fuck_windows_sz();
			cout<<"����"<<p2_r<<endl;
 			cout<<"Ǯ"<<p2_jb<<endl;
	 		cout<<"ʳ��"<<p2_s<<endl;
 			cout<<"��Ⱦ"<<p2_w<<endl;
 			cout<<endl;

 			funk_windows();
 			
		}
 		
		
	}
	return 0;
}





